void printData() {
    Serial.print(f);  // second variable is sin(t)
    Serial.print("\t");
    Serial.print(100 * readings);  // second variable is sin(t)
    Serial.print("\t");             // this last "\t" isn't required, but doesn't hurt
    Serial.println(100 * state);    // third varible is cos(t). make sure to finish with a println!
}

void printOrientation() {
    Serial.print("Orientation: ");  // heading, pitch, roll
    Serial.print(heading);
    Serial.print(", ");
    Serial.print(pitch);
    Serial.print(", ");
    Serial.println(roll);

    float qw, qx, qy, qz;
    filter.getQuaternion(&qw, &qx, &qy, &qz);
    Serial.print("Quaternion: ");  // qw, qx, qy, qz
    Serial.print(qw, 4);
    Serial.print(", ");
    Serial.print(qx, 4);
    Serial.print(", ");
    Serial.print(qy, 4);
    Serial.print(", ");
    Serial.println(qz, 4);
}

void loop() {
    // ... (other code)

    if (read_flag) {
        read_flag = false;
        // Read the motion sensors
        accelerometer->getEvent(&accel);
        gyroscope->getEvent(&gyro);
        magnetometer->getEvent(&mag);

        #if defined(AHRS_DEBUG_OUTPUT)
        Serial.print("I2C took "); Serial.print(millis()-timestamp); Serial.println(" ms");
        #endif

        cal.calibrate(mag);
        cal.calibrate(accel);
        cal.calibrate(gyro);

        // ... (other sensor fusion code)

        printOrientation();

        if (SerialBT.hasClient()) {
            SerialBT.print("Orientation: ");  // heading, pitch, roll
            SerialBT.print(heading);
            SerialBT.print(", ");
            SerialBT.print(pitch);
            SerialBT.print(", ");
            SerialBT.println(roll);

            SerialBT.print("Quaternion: ");  // qw, qx, qy, qz
            SerialBT.print(qw, 4);
            SerialBT.print(", ");
            SerialBT.print(qx, 4);
            SerialBT.print(", ");
            SerialBT.print(qy, 4);
            SerialBT.print(", ");
            SerialBT.println(qz, 4);
        }
    }

    if (SerialBT.available()) {
        Serial.write(SerialBT.read());
    }

    delay(1);
}


#ifdef BETTER_PLOTTER 

#endif

